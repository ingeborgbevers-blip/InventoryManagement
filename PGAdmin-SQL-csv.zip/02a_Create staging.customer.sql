CREATE TABLE staging.customer
(
    customerid integer NOT NULL,
    customername varchar(150) NOT NULL,
    customeremail varchar(255),
    customerphone varchar(50),
    customeraddress text,
    customercreditlimit numeric(12,2),

    CONSTRAINT pk_customer PRIMARY KEY (customerid),
    CONSTRAINT chk_customer_creditlimit_non_negative
        CHECK (customercreditlimit IS NULL OR customercreditlimit >= 0)
);

ALTER TABLE IF EXISTS staging.customer
    OWNER TO postgres;