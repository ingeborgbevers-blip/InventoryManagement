-- Import source CSV files into the staging tables.
-- Example using psql from PowerShell:

-- \copy staging.customer(customerid, customername, customeremail, customerphone, customeraddress, customercreditlimit)
-- FROM 'C:/path/to/Customer.csv'
-- WITH (FORMAT csv, HEADER true, DELIMITER ',', NULL '', ENCODING 'UTF8');