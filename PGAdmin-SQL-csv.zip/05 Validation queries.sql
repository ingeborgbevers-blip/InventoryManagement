SELECT COUNT(*) FROM staging.customer;
SELECT COUNT(*) FROM staging.orders;
SELECT COUNT(*) FROM staging.order_details;
SELECT COUNT(*) FROM staging.product;

SELECT * FROM reporting.vw_orders_enriched LIMIT 20;