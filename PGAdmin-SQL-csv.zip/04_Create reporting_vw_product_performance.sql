DROP VIEW IF EXISTS reporting.vw_product_performance;

CREATE VIEW reporting.vw_product_performance AS
SELECT
    p.productid,
    p.productname,
    p.categoryname,
    p.productlistprice,
    p.productstandardcost,
    p.profit,

    SUM(od.orderitemquantity) AS total_quantity_ordered,
    SUM(od.orderitemquantity * p.productlistprice) AS total_revenue_raw,
    SUM(od.orderitemquantity * p.productstandardcost) AS total_cost_raw,
    SUM(od.orderitemquantity * (p.productlistprice - p.productstandardcost)) AS total_profit_raw,

    SUM(
        CASE WHEN LOWER(od.orderstatus) = 'canceled'
        THEN od.orderitemquantity ELSE 0 END
    ) AS cancelled_quantity,

    SUM(
        CASE WHEN LOWER(od.orderstatus) = 'canceled'
        THEN od.orderitemquantity * p.productlistprice ELSE 0 END
    ) AS cancelled_revenue,

    SUM(
        CASE WHEN LOWER(od.orderstatus) = 'canceled'
        THEN od.orderitemquantity * p.productstandardcost ELSE 0 END
    ) AS cancelled_cost,

    SUM(
        CASE WHEN LOWER(od.orderstatus) = 'canceled'
        THEN od.orderitemquantity * (p.productlistprice - p.productstandardcost) ELSE 0 END
    ) AS cancelled_profit,

    SUM(
        CASE WHEN LOWER(od.orderstatus) <> 'canceled'
        THEN od.orderitemquantity ELSE 0 END
    ) AS actual_quantity,

    SUM(
        CASE WHEN LOWER(od.orderstatus) <> 'canceled'
        THEN od.orderitemquantity * p.productlistprice ELSE 0 END
    ) AS actual_revenue,

    SUM(
        CASE WHEN LOWER(od.orderstatus) <> 'canceled'
        THEN od.orderitemquantity * p.productstandardcost ELSE 0 END
    ) AS actual_cost,

    SUM(
        CASE WHEN LOWER(od.orderstatus) <> 'canceled'
        THEN od.orderitemquantity * (p.productlistprice - p.productstandardcost) ELSE 0 END
    ) AS actual_profit,

    ROUND(
        SUM(CASE WHEN LOWER(od.orderstatus) = 'canceled' THEN od.orderitemquantity * p.productlistprice ELSE 0 END)
        / NULLIF(SUM(od.orderitemquantity * p.productlistprice), 0) * 100,
        2
    ) AS pct_revenue_cancelled,

    ROUND(
        SUM(CASE WHEN LOWER(od.orderstatus) = 'canceled' THEN od.orderitemquantity * (p.productlistprice - p.productstandardcost) ELSE 0 END)
        / NULLIF(SUM(od.orderitemquantity * (p.productlistprice - p.productstandardcost)), 0) * 100,
        2
    ) AS pct_profit_cancelled

FROM staging.product p
LEFT JOIN staging.orderdetails od
    ON p.productid = od.productid
LEFT JOIN staging.orders o
    ON od.orderid = o.orderid
GROUP BY
    p.productid,
    p.productname,
    p.categoryname,
    p.productlistprice,
    p.productstandardcost,
    p.profit;