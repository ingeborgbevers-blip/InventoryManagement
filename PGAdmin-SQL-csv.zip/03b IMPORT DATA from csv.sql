COPY staging.customer
(
    customerid,
    customername,
    customeremail,
    customerphone,
    customeraddress,
    customercreditlimit
)
FROM 'C:/InventoryManagement/Customer.csv'
WITH
(
    FORMAT csv,
    HEADER true,
    DELIMITER ',',
    ENCODING 'UTF8'
);