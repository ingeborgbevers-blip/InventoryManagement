CREATE TABLE staging.warehouse
(
    warehouseid integer NOT NULL,
    warehousename varchar(150) NOT NULL,
    regionid integer NOT NULL,

    CONSTRAINT pk_warehouse 
        PRIMARY KEY (warehouseid),

    CONSTRAINT fk_warehouse_region 
        FOREIGN KEY (regionid)
        REFERENCES staging.region (regionid)
);